<?php
namespace application;

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASSWORD', 'mi6android');
define('DB_NAME', 'db_store');

session_start();