<span>Do you Really to logout</span>
<form action="logout" method="post">
    <input type="submit" value="Yes" name="yes">
</form>

<form action="logout" method="post">
    <input type="submit" value="No" name="no">
</form>

