<div class="container">
    <div class="row">
        <div class="col-lg-4"></div>
        <div class="col-lg-4 text-center"><h3>My Store</h3></div>
        <div class="col-lg-4"></div>
    </div>
</div>
<body>

<div class="container">
    <div class="row">
        <div class="col-lg-2"></div>
        <div class="col-lg-8 text-center"><?php include ($contentView)?></div>
        <div class="col-lg-2"></div>
    </div>
</div>

</body>
<div class="container">
    <div class="row">
        <div class="col-lg-4"></div>
        <div class="col-lg-4 text-center">@v.matviishyn</div>
        <div class="col-lg-4"></div>
    </div>
</div>