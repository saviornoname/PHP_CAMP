<a href="\store\user\login">Login</a><br>
<a href="\store\user\register">Registration</a><br>


